/**
 * Created by epotignano on 15/4/16.
 */

import React from 'react';

function categories(focuses) {
  return <div>
    Enfoques:
  </div>
}


export function DoctorProfileCard(keepData) {
  return  <div className="ui stackable grid">

            <div className="ui column">
              
            </div>

          </div>
}


