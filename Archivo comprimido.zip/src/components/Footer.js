import React, { Component } from 'react';

class Footer extends Component {
  render() {
    return (
      <footer>
        miClinicaWeb ®. Todos los derechos reservados
      </footer>

    )
  }
}

export default Footer;
