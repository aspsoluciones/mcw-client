/**
 * Created by epotignano on 08/03/16.
 */
export const BaseRef = 'http://desa-prog03.miclinicaweb.com/WebApi';
export const ApiRef = BaseRef + '/api';
export const UidRef= 'mcw_uid';
export const TokenRef= 'mcw_token';
export const RefreshTokenRef= 'mcw_refresh_token';
export const ExpiresInRef= 'mcw_expires_in';
