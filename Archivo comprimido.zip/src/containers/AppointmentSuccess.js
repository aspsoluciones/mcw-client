import React, {Component, PropTypes} from 'react';

class AppointmentSuccess extends Component {
    render() {
        return (
            <div className="ui one column grid">
                
            </div>
        );
    }
}

AppointmentSuccess.propTypes = {

};

export default AppointmentSuccess;