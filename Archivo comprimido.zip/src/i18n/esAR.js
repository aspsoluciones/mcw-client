exports.esAR = {
  "ACTIONS" : {
    "IMAGE_UPLOAD": {
      "ERROR": "Error al guardar la imágen",
      "SUCCESS": "Imágen guardada con éxito"
    }
  }
}
