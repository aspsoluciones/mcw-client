/**
 * Created by epotignano on 20/03/16.
 */
var esAR = require('./esAR');
exports.messages = {
  'es-AR' : esAR
}
